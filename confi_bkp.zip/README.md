# confi — Sistema de Controle Financeiro

Aplicação web em PHP 8+ / MySQL / Apache, estruturada em MVC e preparada para execução local com MAMP.

## Estrutura

```text
confi/
├── index.php                    # Front Controller / roteador
├── .htaccess
├── config/
│   ├── config.php
│   └── database.php
├── app/
│   ├── bootstrap.php
│   ├── controllers/
│   ├── models/
│   ├── helpers/
│   └── views/
│       ├── layouts/
│       ├── auth/
│       ├── dashboard/
│       ├── transactions/
│       ├── clients/
│       └── recurrings/
├── public/assets/
│   ├── css/style.css
│   ├── js/app.js
│   ├── js/dashboard.js
│   └── img/client-logo.svg
└── database/confi.sql
```

## Bibliotecas externas

- **jQuery 3.7.1**: `https://code.jquery.com/jquery-3.7.1.min.js`
- **CKEditor 4.22.1 Standard** via CDN oficial: `https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js`
- **Font Awesome 6.7.2** via CDN oficial: `https://use.fontawesome.com/releases/v6.7.2/css/all.css`

O jQuery é usado para interações de formulários, campos condicionais, máscara de telefone e formatação de valores. CKEditor fica incorporado no stack base via CDN oficial; os formulários atuais de Entrada e Saída não exibem o campo Observações. Font Awesome fornece os ícones da interface.

> Observação sobre CKEditor: a distribuição 4.22.1 é a versão open-source mantida no CDN oficial. A linha CKEditor 4 entrou em fim de vida em 2023; para produção, considere migrar para CKEditor 5. A documentação atual do CKEditor confirma o CDN oficial do CKEditor 5, mas a distribuição Cloud CDN atual exige configuração/licenciamento.

## MAMP

1. Copie a pasta `confi` para a pasta `htdocs` do MAMP.
2. Inicie Apache e MySQL.
3. Abra o phpMyAdmin do MAMP.
4. Importe `database/confi.sql`.
5. Confira `config/config.php`:
   - host: `127.0.0.1`
   - porta padrão MAMP: `8889`
   - usuário: `root`
   - senha: `root`
6. Acesse `http://localhost/confi/`.

Se seu MAMP usar outra porta ou senha do MySQL, altere os valores no arquivo de configuração.

## Acesso inicial

- E-mail: `admin@confi.local`
- Senha: `admin123`

## Cartão de crédito e parcelas

Quando um lançamento é salvo com **Cartão de Crédito**:

- o valor total é dividido pelo número de parcelas;
- a primeira parcela vence 1 mês após a data do lançamento, preservando o dia quando possível;
- as demais parcelas vencem nos meses seguintes;
- cada parcela é gravada como um lançamento independente, com o seu próprio `period_month`;
- o status de todas as parcelas começa como **Pendente**;
- a última parcela recebe eventual diferença de centavos para que a soma das parcelas seja exatamente igual ao valor total;
- em cada requisição do sistema, as parcelas com data de vencimento igual ou anterior à data atual são automaticamente alteradas para **Pago**.

Exemplo: R$ 100,00 em 4X lançado em 05/01/2026 cria R$ 25,00 em 05/02, 05/03, 05/04 e 05/05.

O agrupamento é registrado pelos campos `installment_group`, `installment_number`, `installment_total` e `original_date`.

Para atualização automática diária mesmo sem abrir o sistema, o pacote inclui `cron/sync-credit-status.php`. Em macOS/Linux, ele pode ser executado pelo cron uma vez por dia. Além disso, o próprio sistema executa essa sincronização a cada requisição web.

## Lançamentos

Na tela de Lançamentos, entradas e saídas são ordenadas da mais nova para a mais antiga. Cada coluna apresenta três indicadores: total Pago, total geral e a diferença entre ambos.

A seleção de cidade no cadastro de clientes é um dropdown abastecido automaticamente pela UF escolhida usando o serviço de localidades do IBGE.

## Banco de dados

Toda comunicação com o MySQL usa **PDO** e prepared statements. O arquivo SQL inclui os dados financeiros fornecidos no Excel utilizado na versão anterior do projeto, além do usuário administrador, clientes e recorrências de demonstração.
