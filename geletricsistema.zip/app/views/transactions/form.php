<?php require __DIR__.'/../layouts/header.php'; ?>

<div class="page-title compact">
    <h1>
        <span class="heading-flow <?= $isEntrada ? 'green' : 'red' ?>">
            <i class="fa-solid <?= $isEntrada ? 'fa-arrow-up' : 'fa-arrow-down' ?>"></i>
        </span>
        <?= $editing ? 'Editar ' : '' ?><?= $isEntrada ? 'Entrada' : 'Saída' ?>
    </h1>

    <div class="transaction-meta">
        <?php if ($isEntrada): ?>
            <div class="service-order-badge">
                <span>Ordem de Serviço</span>
                <strong><?= e(service_order_label($transaction['service_order_number'] ?? 0)) ?></strong>
            </div>
        <?php endif; ?>
        <div class="date-badge">
            <span>Lançado em</span>
            <strong><?= e(date_br($transaction['original_date'] ?: $transaction['transaction_date'])) ?></strong>
        </div>
    </div>
</div>

<?php if ($errors): ?>
    <div class="alert alert-error">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <?= e(implode(' ', $errors)) ?>
    </div>
<?php endif; ?>

<?php if ($editing && (int) ($transaction['installment_total'] ?? 0) > 1): ?>
    <div class="installment-info">
        <i class="fa-solid fa-credit-card"></i>
        Parcela <?= (int) $transaction['installment_number'] ?> de <?= (int) $transaction['installment_total'] ?> · vencimento <?= e(date_br($transaction['transaction_date'])) ?> · valor <?= e(money($transaction['amount'])) ?>
    </div>
<?php endif; ?>

<form class="form-panel" method="post" action="<?= e(url($isEntrada ? 'entrada' : 'saida', $editing ? ['id' => $transaction['id']] : [])) ?>">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">

    <?php if ($isEntrada): ?>
        <div class="form-group">
            <label for="client_id">Cliente</label>
            <div class="inline-select">
                <select id="client_id" name="client_id">
                    <option value="">Selecione um cliente</option>
                    <?php foreach ($clients as $c): ?>
                        <option value="<?= (int) $c['id'] ?>" <?= (string) $c['id'] === (string) ($transaction['client_id'] ?? '') ? 'selected' : '' ?>>
                            <?= e($c['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <a href="<?= e(url('cliente', ['return' => 'entrada'])) ?>" class="add-client">
                    <span><i class="fa-solid fa-plus"></i></span>
                    Adicionar Cliente
                </a>
            </div>
        </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="item">Item</label>
        <input id="item" name="item" value="<?= e($transaction['item']) ?>" placeholder="Item" required>
    </div>

    <div class="form-group">
        <label for="amount">Valor</label>
        <input id="amount" name="amount" value="<?= e($transaction['amount'] !== '' ? number_format((float) $transaction['amount'], 2, ',', '') : '') ?>" placeholder="0,00" inputmode="decimal" required>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="transaction_date">Data</label>
            <input
                id="transaction_date"
                type="date"
                name="transaction_date"
                value="<?= e($transaction['transaction_date']) ?>"
                <?= $editing && (int) ($transaction['installment_total'] ?? 0) > 1 ? 'readonly title="A data desta parcela é calculada automaticamente"' : '' ?>
            >
        </div>

        <div class="form-group">
        <label for="payment_method">Método de Pagamento</label>
        <select id="payment_method" name="payment_method">
            <?php foreach (payment_options() as $o): ?>
                <option value="<?= e($o) ?>" <?= $o === $transaction['payment_method'] ? 'selected' : '' ?>><?= e($o) ?></option>
            <?php endforeach; ?>
            <?php if ($legacyPayment): ?>
                <option value="<?= e(trim((string) $transaction['payment_method'])) ?>" selected>Crédito (importado)</option>
            <?php endif; ?>
        </select>
    </div>
    
    </div>

    

    <div class="form-row credit-fields">
        <div class="form-group">
            <label for="installments">Nº de Parcelas</label>
            <select id="installments" name="installments">
                <?php foreach (parcel_options() as $o): ?>
                    <option value="<?= e($o) ?>" <?= $o === $transaction['installments'] ? 'selected' : '' ?>><?= e($o) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="brand">Bandeira</label>
            <select id="brand" name="brand">
                <?php foreach (brand_options() as $o): ?>
                    <option value="<?= e($o) ?>" <?= $o === $transaction['brand'] ? 'selected' : '' ?>><?= e($o) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="status">Status do Pagamento</label>
            <select id="status" name="status">
                <?php foreach (status_options() as $o): ?>
                    <option value="<?= e($o) ?>" <?= $o === $transaction['status'] ? 'selected' : '' ?>><?= e($o) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <?php if ($editing && (int) ($transaction['installment_total'] ?? 0) > 1): ?>
        <div class="helper-text">
            <i class="fa-solid fa-circle-info"></i>
            Alterar esta parcela atualiza somente o lançamento selecionado.
        </div>
    <?php else: ?>
        <div class="helper-text credit-help">
            <i class="fa-solid fa-circle-info"></i>
            No cartão de crédito, o sistema cria automaticamente as parcelas com vencimento mensal a partir de 30 dias após o lançamento e deixa todas como Pendente até a data chegar.
        </div>
    <?php endif; ?>

    <div class="form-actions">
        <a href="<?= e(url('lancamentos')) ?>" class="btn btn-back">
            <i class="fa-solid fa-arrow-left"></i>
            Voltar
        </a>
        <button class="btn btn-primary" type="submit">
            <i class="fa-solid fa-floppy-disk"></i>
            Salvar
        </button>
        
    </div>
    <div class="row justify-content-end py-3">
        <div class="col-lg-12 col-10">
            <?php if ($isEntrada): ?>
                <?php if ($editing && !empty($transaction['service_order_number'])): ?>
                    <a
                        href="<?= e(url('ordem-de-servico/imprimir', ['id' => $transaction['id']])) ?>"
                        class="btn btn-secondary"
                        target="_blank"
                        rel="noopener"
                    >
                        <i class="fa-solid fa-print"></i>
                        Imprimir Ordem de Serviço
                    </a>
                <?php else: ?>
                    <a
                        href="<?= e(url('ordem-de-servico/imprimir', ['id' => $transaction['id']])) ?>"
                        class="btn btn-secondary"
                        target="_blank"
                        rel="noopener"
                    >
                        <i class="fa-solid fa-print"></i>
                        Imprimir Ordem de Serviço
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</form>

<?php if ($editing): ?>
    <form method="post" action="<?= e(url('lancamento/excluir')) ?>" class="delete-form" onsubmit="return confirm('Excluir este lançamento? Em lançamentos parcelados, todas as parcelas do grupo serão excluídas.');">
        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= (int) $transaction['id'] ?>">
        <button class="link-danger" type="submit">
            <i class="fa-regular fa-trash-can"></i>
            Excluir lançamento
        </button>
    </form>
<?php endif; ?>

<?php require __DIR__.'/../layouts/footer.php'; ?>
